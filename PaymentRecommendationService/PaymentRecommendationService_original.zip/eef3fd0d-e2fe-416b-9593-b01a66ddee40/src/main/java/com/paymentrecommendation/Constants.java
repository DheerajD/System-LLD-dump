package com.paymentrecommendation;

public class Constants {
    public static final double LOB_INVESTMENT_MAX_LIMIT = 100000d;
    public static final double LOB_CREDIT_CARD_PAYMENT_MAX_LIMIT = 100000d;
    public static final double LOB_COMMERCE_MAX_LIMIT = 200000d;
}
