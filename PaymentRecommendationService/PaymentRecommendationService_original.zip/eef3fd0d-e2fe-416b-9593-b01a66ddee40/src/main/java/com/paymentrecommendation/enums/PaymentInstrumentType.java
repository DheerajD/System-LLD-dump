package com.paymentrecommendation.enums;

public enum PaymentInstrumentType {
    CREDIT_CARD,
    DEBIT_CARD,
    UPI,
    NETBANKING;
}
