package com.paymentrecommendation.enums;

public enum Issuer {
    HDFC,
    AMEX,
    SBI,
    CITI,
    AXIS,
    ICICI
}
